#ifndef CONSTANTS_H
#define CONSTANTS_H

//Constants for the mainwindow

const int NUMLEDS = 10;
const int NUMSWITCHES = 10;
const int NUMSEVENSEGMENT = 6;
const int NUMSEVENSEGPARTS = 8;
const int NUMSEVENSEGPARTSDEC = 8; //8th part of seven segment is the decimal
const char SEGLETTERS[] = {'A','B','C','D','E','F','G','H'};

const QSize BOARD_PIXMAP_SIZE {827, 674};
const QSize SWITCH_SIZE {34, 60};


#endif // CONSTANTS_H
