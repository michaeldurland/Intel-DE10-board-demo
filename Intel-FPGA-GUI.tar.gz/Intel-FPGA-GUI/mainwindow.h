#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QGraphicsScene>
#include <QLabel>
#include <QColor>
#include <QList>
#include <QPushButton>
#include <QTimer>

/**
 * class SWITCH
 * Description: Represents a toggle switch on the board.
 * Clicking the button toggles the state.
 * Custom painting shows the switch physically up or down on the board.
 */
class SWITCH : public QPushButton
{
    Q_OBJECT
public:
    SWITCH(QWidget* parent = nullptr);
    
protected:
    virtual void paintEvent(QPaintEvent *event) override;
};

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

protected:
    virtual void paintEvent(QPaintEvent *event) override;
    virtual void resizeEvent(QResizeEvent* event) override;

private slots:
    void switchFlipped();
    void buttonReleased();
    void segChange();
    void setSegment(int segment, std::string value);
    void ledChange(bool newLEDState, short ledNum);
    void updateSevenSeg(std::string binaryStr);
    void hexToSegment(std::string hexVal);
    void labelScale(QLabel* label);
    void increment_timer();


private:
    Ui::MainWindow *ui;
    
    QColor m_window_background_color;
    QList<SWITCH*> m_switches;
    float m_width_scale = 1.0f;
    float m_height_scale = 1.0f;
    QTimer m_timer;
    int m_time_running = 0;

};
#endif // MAINWINDOW_H
