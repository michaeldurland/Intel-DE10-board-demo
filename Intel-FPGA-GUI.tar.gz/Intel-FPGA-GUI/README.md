# Intel FPGA GUI  
A GUI to interface Intel FPGAs.

![alt text](https://github.com/MCMANIRX/Intel-FPGA-GUI/blob/main/de10%20resource/de10-mockup.png)

